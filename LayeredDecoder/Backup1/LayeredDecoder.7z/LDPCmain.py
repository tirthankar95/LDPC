import LDPCHelper as LD
import numpy as np
import Graph as Graph
import Global as Global
import time
import warnings

Mat=[]
H=[]
def init():
    global Mat,H
    H=np.random.randint(0,2,(Global.n-Global.k,Global.n))
    Mat=np.split(H,Global.Layers)
    
def demod(codeword):
    indx0=np.where(codeword>0)
    indx1=np.where(codeword<=0)
    codeword[indx0]=0
    codeword[indx1]=1
    return codeword
    
def LayeredLDPC0():
    global Mat,l_intrinsic
    lin=l_intrinsic
    LMat=[[0 for j in range(Global.n)] for i in range(Global.Layers)]
    for i in range(Global.mxIter):
        for j in range(Global.Layers):
            lin=lin-LMat[j]
            L=np.multiply(Mat[j],lin)
            indx=np.where(L==0)
            L[indx]=np.nan
            S=np.sign(L)
            S=np.nanprod(S,axis=1).reshape(Global.sz,1)
            l=LD.MIN(np.abs(L))
            L=np.sign(L/S)*l
            lin=(lin+np.nansum(L,axis=0)).reshape(1,Global.n)
            LMat[j]=np.nansum(L,axis=0).reshape(1,Global.n)
    res=np.dot(H,demod(lin).T)%2
    return res,lin

# This function is suppose to return the reward.
# l_instrinsic will come from parent
def rewardLDPC1(state):
    global l_intrinsic
    lin=l_intrinsic
    start=0;reward=0
    LMat=[[0 for j in range(Global.n)] for i in range(Global.Layers)]
    for iter_ in range(Global.mxIter):
        while start < Global.Layers:
            action=state[start:start+Global.subGroups]
            start+=Global.subGroups
            for ch in action:
                j=int(ch)
                lin=lin-LMat[j]
                L=np.multiply(Mat[j],lin)
                indx=np.where(L==0)
                L[indx]=np.nan
                S=np.sign(L)
                S=np.nanprod(S,axis=1).reshape(Global.sz,1)
                l=LD.MIN(np.abs(L))
                L=np.sign(L/S)*l
                lin=(lin+np.nansum(L,axis=0)).reshape(1,Global.n)
                LMat[j]=np.nansum(L,axis=0).reshape(1,Global.n)
        res=np.dot(H,demod(lin).T)%2
        if np.all(res==0):
            reward=reward+5
            break
        else:
            reward=reward-1
    if Global.Test1==True:
        return res,lin
    else:
        return reward
            
def LayeredLDPC1(obj):
    try:
        p=len(Graph.g.adj[obj.id])
    except:
        obj.value=rewardLDPC1(obj.state)
        return obj.value
    for child in Graph.g.adj[obj.id]:
        obj.value+=(1/p)*(child.value+LayeredLDPC1(child))
    
def display(O):
    sample=open("op.txt","w")
    qu=[];qu1=[]
    qu.append(O.id)
    print(O.value,file=sample)
    print("-----------------",file=sample)
    while len(qu)!=0:
        while len(qu)!=0:
            par=qu.pop()
            try:
                Graph.g.adj[par]
            except:
                continue
            for child in Graph.g.adj[par]:
                qu1.append(child.id)
                print(child.value,end=" , ",file=sample)
        if len(qu1)!=0:
            print("\n-----------------",file=sample)
        qu=qu1
        qu1=[]
        
def Test0():
    global Mat,H,l_intrinsic
    print('Test0')
    Global.n=7
    Global.k=3
    Global.Layers=2
    Global.mxIter=2
    Global.sz=(Global.n-Global.k)//Global.Layers
    H=np.array([[1,1,1,0,1,0,0],[0,0,0,1,0,1,1],[1,1,0,1,0,0,1],[0,0,1,0,1,1,0]])
    Mat=np.split(H,Global.Layers)
    l_intrinsic=np.array([0.2,-0.3,1.2,-0.5,0.8,0.6,-1.1])
    result,l_intrinsic_R=LayeredLDPC0()
    print('Before:\n',demod(l_intrinsic))
    print('Final Result:\n',result.T,'\n',l_intrinsic_R)
    
def Test1():
    global Mat,H,l_intrinsic
    print('Test1')
    Global.n=7
    Global.k=3
    Global.Layers=2;Str="01"
    Global.mxIter=2
    Global.sz=(Global.n-Global.k)//Global.Layers
    H=np.array([[1,1,1,0,1,0,0],[0,0,0,1,0,1,1],[1,1,0,1,0,0,1],[0,0,1,0,1,1,0]])
    Mat=np.split(H,Global.Layers)
    l_intrinsic=np.array([0.2,-0.3,1.2,-0.5,0.8,0.6,-1.1])
    result,l_intrinsic_R=rewardLDPC1(Str)
    print('Before:\n',demod(l_intrinsic))
    print('Final Result:\n',result.T,'\n',l_intrinsic_R)
    
if __name__=='__main__':
    if Global.NoWarnings==True:
        warnings.filterwarnings("ignore")
    if Global.Test0==True:
        Test0()
    elif Global.Test1==True:
        Test1()
    else:
    #...
        init()
        LD.init()
        Graph.counter=0
        np.random.seed(int(time.time()))
        l_intrinsic=np.random.rand(1,Global.n)-0.5
        O=Graph.node(0,"")
        Graph.build(O,O.state)
        for episodes in range(Global.Episodes):
            LayeredLDPC1(O)
        display(O)
    #...

    
    